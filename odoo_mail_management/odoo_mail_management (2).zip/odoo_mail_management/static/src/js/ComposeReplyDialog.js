/** @odoo-module **/
import { Component, useState, useRef } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { Dialog } from "@web/core/dialog/dialog";

export class ComposeReplyDialog extends Component {
    setup() {
        this.orm = useService("orm");
        this.state = useState({
            recipient: this.props.mail.email_from,
            subject: `Re: ${this.props.mail.subject}`,
            content: "",
            attachedFiles: []
        });
        this.fileInputRef = useRef('fileInput');
    }

    async sendReply() {
        debugger;
        const { recipient, subject, content } = this.state;
        if (!content) {
            alert("Please enter a message");
            return;
        }
        await this.orm.call('mail.mail', 'reply_mail', [this.props.mail.id], { reply_content: content });
        this.props.close();
        window.location.reload();
    }

    addAttachment(ev) {
        debugger;
        const file = ev.target.files[0];
        if (file) {
            this.state.attachedFiles.push(file);
        }
    }

    closePopup() {
        this.props.close();
    }
}

ComposeReplyDialog.template = 'ComposeReplyDialog';
ComposeReplyDialog.components = { Dialog };
