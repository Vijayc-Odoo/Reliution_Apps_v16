/** @odoo-module **/
import { Component, useState } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";
import { Dialog } from "@web/core/dialog/dialog";

export class ComposeForwardDialog extends Component {
    setup() {
        this.orm = useService("orm");
        this.state = useState({
            recipient: "",
            subject: `Fwd: ${this.props.mail.subject}`,
            content: ""
        });
    }

    async sendForward() {
        const { recipient, content } = this.state;
        if (!recipient || !content) {
            alert("Please enter recipient and message");
            return;
        }
        await this.orm.call('mail.mail', 'forward_mail', [this.props.mail.id], {
            forward_recipient: recipient,
            forward_content: content
        });
        this.props.close();
        window.location.reload();
    }

    closePopup() {
        this.props.close();
    }
}

ComposeForwardDialog.template = 'ComposeForwardDialog';
ComposeForwardDialog.components = { Dialog };

///** @odoo-module **/
//import { Component, useState, useRef } from "@odoo/owl";
//import { useService } from "@web/core/utils/hooks";
//import { Dialog } from "@web/core/dialog/dialog";
//
//export class ComposeForwardDialog extends Component {
//    setup() {
//        this.orm = useService("orm");
//        this.state = useState({
//            recipient: "",
//            subject: `Fwd: ${this.props.mail.subject}`,
//            content: ""
//        });
//    }
//
//    async sendForward() {
//        const { recipient, content } = this.state;
//        if (!recipient || !content) {
//            alert("Please enter recipient and message");
//            return;
//        }
//        await this.orm.call('mail.mail', 'forward_mail', [this.props.mail.id], {
//            forward_recipient: recipient,
//            forward_content: content
//        });
//        this.props.close();
//        window.location.reload();
//    }
//
//    closePopup() {
//        this.props.close();
//    }
//}
//
//ComposeForwardDialog.template = 'ComposeForwardDialog';
//ComposeForwardDialog.components = { Dialog };
